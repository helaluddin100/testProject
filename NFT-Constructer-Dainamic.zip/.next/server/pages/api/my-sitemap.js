"use strict";
(() => {
var exports = {};
exports.id = 112;
exports.ids = [112];
exports.modules = {

/***/ 6212:
/***/ ((module) => {

module.exports = require("sitemap");

/***/ }),

/***/ 2781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 3261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const { SitemapStream , streamToPromise  } = __webpack_require__(6212);
const { Readable  } = __webpack_require__(2781);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    // An array with your links
    const links = [
        {
            url: "/",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/nft-website-development",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/website-design",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/website-analysis",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/smart-contract",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/smart-contract-analysis",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/about",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/blog",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/portfolio",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/contract",
            changefreq: "daily",
            priority: 0.9
        },
        {
            url: "/terms",
            changefreq: "daily",
            priority: 0.9
        }, 
    ];
    // Create a stream to write to
    const stream = new SitemapStream({
        hostname: `https://${req.headers.host}`
    });
    res.writeHead(200, {
        "Content-Type": "application/xml"
    });
    const xmlString = await streamToPromise(Readable.from(links).pipe(stream)).then((data)=>data.toString()
    );
    res.end(xmlString);
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3261));
module.exports = __webpack_exports__;

})();